package Entidade;

public interface Observer {
    void atualizar(String mensagem);
}
