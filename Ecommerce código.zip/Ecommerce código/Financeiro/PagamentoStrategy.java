package Financeiro;

public interface PagamentoStrategy {
    public void processarPagamento(double valor);
}
